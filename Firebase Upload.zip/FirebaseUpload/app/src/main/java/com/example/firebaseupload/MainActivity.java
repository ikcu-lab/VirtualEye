package com.example.firebaseupload;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {





    private static final int PICK_IMAGE_REQUEST = 1;
    public String CAPTION = "caption";
    @BindView(R.id.button_choose_image)
    Button buttonChooseImage;
    @BindView(R.id.caption_text_file_name)
    TextView captionTextFileName;
    @BindView(R.id.image_view)
    ImageView imageView;
    @BindView(R.id.progress_bar)
    ProgressBar progressBar;
    @BindView(R.id.button_upload)
    Button buttonUpload;
    @BindView(R.id.text_view_show_uploads)
    TextView textViewShowUploads;


    private Uri mImageUri;


    private FirebaseStorage storage = FirebaseStorage.getInstance();
    // Write a message to the database
//    Realtime database
//    private FirebaseDatabase database = FirebaseDatabase.getInstance();
//    DatabaseReference myRef = database.getReference("URL");
    // Access a Cloud Firestore instance from your Activity
    FirebaseFirestore db = FirebaseFirestore.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        progressBar.setVisibility(View.GONE);
        buttonUpload.setEnabled(true);
        listenToDocument();
    }

    @OnClick({R.id.button_choose_image, R.id.button_upload, R.id.text_view_show_uploads})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.button_choose_image:
                openFileChooser();
                break;
            case R.id.button_upload:
                uploadFile();

                break;
            case R.id.text_view_show_uploads:
                break;
        }
    }

    private void uploadFile() {
        String path = "firememes/" + UUID.randomUUID() + ".jpg";

        StorageReference firememeRef = storage.getReference(path);

        UploadTask uploadTask = firememeRef.putFile(mImageUri);
        //progress_bar
        //button_upload
        progressBar.setVisibility(View.VISIBLE);
        buttonUpload.setEnabled(false);

        uploadTask.addOnCompleteListener(MainActivity.this, task -> {
            Log.i("MA","Upload Task Complete");
            progressBar.setVisibility(View.GONE);
            buttonUpload.setEnabled(true);
        });

        Task<Uri> getDownloadUriTask = uploadTask.continueWithTask(
                task -> {
                    if (!task.isSuccessful()){
                        throw Objects.requireNonNull(task.getException());
                    }
                    return firememeRef.getDownloadUrl();
                }
        );

        getDownloadUriTask.addOnCompleteListener(MainActivity.this, task -> {
            if (task.isSuccessful()) {
                Uri downloadUri = task.getResult();

//                    Upload Realtime Database Code
//                    myRef.setValue(downloadUri.toString());

//                    Upload Cloud Firestore
                // Create a new user with a first and last name
                Map<String, Object> user = new HashMap<>();
                if (downloadUri != null) {
                    user.put("URL", downloadUri.toString());
                }


                // Add a new document with a generated ID
                db.collection("users").document("URL")
                        .set(user)
                        .addOnSuccessListener(aVoid -> Log.d("TAG", "Document Succesfully written"))
                        .addOnFailureListener(e -> Log.w("TAG", "Error adding document", e));

            }


        });


    }

    public void listenToDocument() {
        // [START listen_document]
        final DocumentReference docRef = db.collection("users").document("CAPTION");
        docRef.addSnapshotListener((snapshot, e) -> {
            if (e != null) {
                Log.w("LISTENER", "Listen failed.", e);
                return;
            }

            if (snapshot != null && snapshot.exists()) {
                CAPTION = String.valueOf(snapshot.getData());
                Log.d("LISTENER", "Current data: " + CAPTION);
                captionTextFileName.setText(CAPTION);
            } else {
                Log.d("LISTENER", "Current data: null");
            }
        });
        // [END listen_document]
    }


    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            mImageUri = data.getData();

            Picasso.get().load(mImageUri).into(imageView);

        }
    }
    /*
    Get Image extension such as .jpg .png etc.


    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));

    }

    */
}
